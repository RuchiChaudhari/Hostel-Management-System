<div class="brand clearfix">
		<a href="#" class="logo" style="font-size:16px; color:#fff;">Hostel Management System</a>
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">
			<li class="ts-account">
				
				
			</li>
		</ul>
	</div>